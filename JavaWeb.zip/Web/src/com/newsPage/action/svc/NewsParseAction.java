package com.newsPage.action.svc;

import com.newsPage.db.vo.NewsBean;
import com.newsPage.action.controller.Action;
import com.newsPage.action.controller.ActionForward;
import com.newsPage.db.dao.NewsDAO;
import com.newsPage.action.util.ConsoleCommand;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NewsParseAction implements Action {
    @Override
    public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        var newsDAO = new NewsDAO();
        var newsBean = new NewsBean();
        boolean dataInsertFlg = false;

        try
        {
            String URL = request.getParameter("searchNews");
            System.out.println("URL 검색 시작함: " + URL);
            ConsoleCommand cmd = new ConsoleCommand();
            String command = cmd.inputCommand("python ./bin/summary/main.py " + URL + " -all");
            String result = cmd.execCommand(command);

            newsBean.setHash(URL);
            newsBean.setJson_data(result);
            //데이터 베이스에 단어 등록
            dataInsertFlg = newsDAO.insertNewsJsonData(newsBean);

            if(dataInsertFlg == true)
            {
                String jsonData = newsDAO.selectSearchNewsJson(newsBean);
                response.setCharacterEncoding("utf-8");
                response.getWriter().write(jsonData);
            }
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            newsDAO.con.close();
        }
        return null;
    }
}
