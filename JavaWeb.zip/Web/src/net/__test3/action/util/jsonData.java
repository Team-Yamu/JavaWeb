package net.__test3.action.util;

import java.util.List;

public class jsonData
{
    public jsonData()
    {
        name = null;
        target_trans_word = null;
    }

    public String name;
    public List target_trans_word;
}
