$(function()
{
    $("#searchNewsBtn").on("click",function ()
    {
        $.ajax
        ({
            type:"post",
            url:"/newsParse.nw",
            //key : value 방식으로 보냄
            data:$("#search").serialize(),
            dataType : 'json',
            success: whenSuccess,
            error: notExistData
        })
    })
});

// function loading()
// {
//     $('#popup').fadeIn(200);
//     StartClock();
// }

function notExistData(error)
{
    alert("해당 기사를 찾을 수 없습니다.");
    $("#searchMyNews-view").css("display","none");
}

//값을 가져왔을때 실행
function whenSuccess(result)
{
    $('#popup').fadeOut(200);
    $("#searchMyNews-view").css("display","block");
    var html = '';
    $.each(result, function(index,entry){
        html += '<div id="newsTitle">'+entry.title+'</div>';
        html+= '<div id="newsImage"><img src="data:image/png;base64,'+entry.base64_top_img+'"></div>';
        html += '<div id="newsSummaryTitle">요약</div>';
        html += '<div id="newsSummary">'+entry.summary+'</div>';
        html += '<div id="newsMain"><div id="newsMainTitle">전문</div>';
        html += entry.text;
        html += '<div id="moreNews"><button>전문보기</button></div>';
    });
    $("#searchMyNews-view").html(html);
    $('#search').each(function(){
        this.reset();
    });
}

// function StartClock() {
//     loading();
//     timerId = setInterval(loading, 1000);
// }
// function loading() {
//     $('#popup p a').animate({marginLeft: '15px'}, 700);
//     $('#popup p a').animate({marginLeft: '0px'}, 700);
// }
// function StopClock() {
//     if(timerId != null) {
//
//         clearInterval(timerId);
//     }
// }