# TO-DO DEPENDENCY

---

    pip install requests nltk bs4 django newspaper3k

---